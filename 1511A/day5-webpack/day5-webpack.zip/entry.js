let a = 10;
a  = a + 2;
console.log(a);