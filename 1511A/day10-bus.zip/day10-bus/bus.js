(function(){
    Vue.prototype.bus = new Vue();
})()