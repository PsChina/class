export default {
    msg: 'Hello Vuex!',
    goods1Price: 0,
    goods2Price: 0,
    goods3Price: 0,
};
