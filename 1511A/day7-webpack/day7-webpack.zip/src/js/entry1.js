import '../css/style.css';
import '../index.html';

import $ from 'jquery';

console.log(1);

$('body').append('<div>模块1</div>')