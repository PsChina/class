console.log(2);

import $ from 'jquery';

$('body').append('<div>模块2</div>')