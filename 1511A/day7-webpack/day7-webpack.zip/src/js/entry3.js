console.log(3)

import $ from 'jquery';

$('body').append('<div>模块3</div>')