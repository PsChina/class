<template>
  <div id="app">
      <my-component></my-component>
  </div>
</template>

<script>
import myComponent from '@/components/myComponent';

export default {
  name: 'App',
  components: {
    myComponent
  }
}
</script>

<style>
</style>
